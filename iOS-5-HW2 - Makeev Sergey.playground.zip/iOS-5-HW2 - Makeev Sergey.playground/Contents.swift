import UIKit

let greeting = "Hello, USA"
print(greeting)

typealias City = (nameCity: String, distanceToCity: Int, populationCity: Int)
typealias Vehicle = (brand: String?, model: String?, rentCost: Int?, fuelСonsumption: Int?, ticketCost: Int?)

var airplane: Vehicle = (brand: "Airbus", model: "A320", rentCost: nil, fuelСonsumption: nil, ticketCost: 715)

let quantityOfPersons = 2
var hotelCost: Int
var foodOnePerson: Int
var ticketPricePersonUSD: Int


//======== Начальная точка ========


let startPoint: City = (nameCity: "Chelyabinsk, Russia", distanceToCity: 0, populationCity: 1150000)

ticketPricePersonUSD = 715
let distanceToUSA: Int = 10095
let isPlane = true
var expensesStartPoint = 0

if distanceToUSA >= 2000 {
    isPlane == true
} else {
    isPlane == false
}

if isPlane {
    expensesStartPoint = quantityOfPersons * Int(airplane.ticketCost ?? 0)
}

print("""
Finally we are going to California.
Our trip begins in \(startPoint.nameCity).
Tickets cost \(expensesStartPoint)$ for two persons.
Distance is \(distanceToUSA)km.

""")


//======== Лос-Анджелес ========


let cityLA: City = (nameCity: "Los Angeles", distanceToCity: 10095, populationCity: 3884307)

var gasCostUSD: Float = 1.3
var gasConsumprionLitre = 10
var rentCarDayUSD = 40

//----Добавляем новые виды транспорта----

var car: Vehicle = (brand: "BMW", model: "X5", rentCost: 50, fuelСonsumption: 12, ticketCost: nil)
var bus: Vehicle = (brand: nil, model: nil, rentCost: nil, fuelСonsumption: nil, ticketCost: 25)

hotelCost = 100
foodOnePerson = 50
var daysInLA = 2
let distanceInLA = 50
var hotelLA = hotelCost * daysInLA
var foodLA = quantityOfPersons * foodOnePerson * daysInLA
var expensesLA: Int

//----Считаем затраты на машину и автобус----

var carExpenses = Float((car.rentCost ?? 0) * daysInLA) + (Float((car.fuelСonsumption ?? 0) * distanceInLA)) * gasCostUSD / 100
var busExpenses = (bus.ticketCost ?? 0) * quantityOfPersons

//----Если разница в затратах между автобусом и машиной меньше 100$, то едем на машине

if (Int(carExpenses) - busExpenses) >= 100 {

//----Затраты в Лос Анджелесе (в случае с автобусом) + выводим на печать----

expensesLA = busExpenses + hotelLA + foodLA
print("""
Our first point of stay is \(cityLA.nameCity).
Population of this city is \(cityLA.populationCity) people.
We spend \(hotelLA)$ for living in a Hotel, \(foodLA)$ on food,
on Bus \(busExpenses)$.

""")

} else {

//----Затраты в Лос Анджелесе (в случае с машиной) + выводим на печать----

expensesLA = Int(carExpenses) + hotelLA + foodLA
print("""
Our first point of stay is \(cityLA.nameCity).
Population of this city is \(cityLA.populationCity) people.
We spend \(hotelLA)$ for living in a Hotel, \(foodLA)$ on food,
We take a \(car.brand ?? "Default") \(car.model ?? "Default"),
rent is \((car.rentCost ?? 0) * daysInLA)$,
gasoline - \((Float((car.fuelСonsumption ?? 0) * distanceInLA)) * gasCostUSD / 100)$.

""")
}


//======== Сан-Луис Обиспо ========


var citySanLO: City = (nameCity: "San Luis Obispo", distanceToCity: 350, populationCity: 47302)

var quantityOfDaysCitySanLO = 1
hotelCost = 70
foodOnePerson = 30
var daysInSanLO = 1

//----Новая машина и поезд----

car = (brand: "Mercedes", model: "GLS", rentCost: 60, fuelСonsumption: 14, ticketCost: nil)

var train: Vehicle = (brand: nil, model: nil, rentCost: nil, fuelСonsumption: nil, ticketCost: 35)

var hotelSanLO = hotelCost * daysInSanLO
var foodSanLO = quantityOfPersons * foodOnePerson * daysInSanLO
var expensesSanLO = 0

//----Считаем затраты на машину и поезд----

carExpenses = Float((car.rentCost ?? 0) * daysInSanLO) + (Float((car.fuelСonsumption ?? 0) * citySanLO.distanceToCity)) * gasCostUSD / 100

var trainExpenses = (train.ticketCost ?? 0) * quantityOfPersons

//----Если разница в затратах между автобусом и поездом меньше 100$, то едем на машине

if (Int(carExpenses) - busExpenses) >= 50 {

    //----Считаем затраты в Сан-Луис Обиспо (в случае с автобусом) и выводим на печать---

    expensesSanLO = busExpenses + hotelSanLO + foodSanLO
    print("""
    Next stop is \(citySanLO.nameCity) in \(citySanLO.distanceToCity)km from \(cityLA.nameCity).
    Population is \(citySanLO.populationCity) people.
    Our expenses:
    \(hotelSanLO)$ on a hotel.
    \(trainExpenses)$ on a train.
    \(foodSanLO)$ on food.

    """)
} else {

    //----Считаем затраты в Сан-Луис Обиспо (в случае с машиной) и выводим на печать---

    expensesSanLO = Int(carExpenses) + hotelLA + foodLA
    print("""
    Next stop is \(citySanLO.nameCity) in \(citySanLO.distanceToCity)km from \(cityLA.nameCity).
    Population is \(citySanLO.populationCity) people.
    Our expenses:
    \(hotelSanLO)$ on a hotel.
    \((Float((car.fuelСonsumption ?? 0) * citySanLO.distanceToCity)) * gasCostUSD / 100)$ on gasoline and \((car.rentCost ?? 0) * daysInSanLO))$ on car rent.
    \(foodSanLO)$ on food.

    """)
}


//======== Монтерей ========


var cityMonterey: City = (nameCity: "Monterey", distanceToCity: 240, populationCity: 28352)

var daysInMonterey = 1
hotelCost = 80
foodOnePerson = 40
var hotelMonterey = hotelCost * daysInMonterey
var foodMonterey = quantityOfPersons * foodOnePerson * daysInMonterey


//----Заводим новые виды транспорта. Поезд и автобус делаем недоступным----

car = (brand: "BMW", model: "5", rentCost: 55, fuelСonsumption: 9, ticketCost: nil)

var newTrain: Vehicle? = nil

var newBus: Vehicle? = nil

//----Посчитаем затраты на авто и затраты в целом----

carExpenses = Float((car.rentCost ?? 0) * daysInMonterey) + (Float((car.fuelСonsumption ?? 0) * cityMonterey.distanceToCity)) * gasCostUSD / 100

var expensesMonterey = Int(carExpenses) + hotelLA + foodLA

print("""
Then we are going to \(cityMonterey.nameCity). That is \(cityMonterey.distanceToCity)km further.
Another small town with population of \(cityMonterey.populationCity) people.
Our expenses:
\(hotelMonterey)$ on hotel.
\(foodMonterey)$ on food.

""")

//----Выбираем имеющиеся варианты (если автобусов и поездов нет, едем на машине)----

if newTrain != nil {
    print("I travel by train")
} else if newBus != nil {
    print("I travel by bus")
} else {
    print("I travel by \(car.brand ?? "Default") \(car.model ?? "Default").")
}


//======== Сан-Франциско ========

var citySanFr: City = (nameCity: "San Francisco", distanceToCity: 190, populationCity: 879961)

var daysInSanFr = 2
hotelCost = 120
foodOnePerson = 60

var hotelSanFr = hotelCost * daysInSanFr
var foodSanFr = quantityOfPersons * foodOnePerson * daysInSanFr

//----Заводим новые виды транспорта. Поезд и автобус делаем недоступным----

car = (brand: "Ford", model: "Mustang", rentCost: 65, fuelСonsumption: 14, ticketCost: nil)

var otherCar: Vehicle = (brand: "VW", model: "Golf", rentCost: 35, fuelСonsumption: 14, ticketCost: nil)

//----и переменную "бюджет"----

let budget = 200

//----Считаем расходы на машины----

carExpenses = Float((car.rentCost ?? 0) * daysInSanFr) + (Float((car.fuelСonsumption ?? 0) * citySanFr.distanceToCity)) * gasCostUSD / 100

var otherCarExpenses = Float((otherCar.rentCost ?? 0) * daysInSanFr) + (Float((car.fuelСonsumption ?? 0) * citySanFr.distanceToCity)) * gasCostUSD / 100

print("""
In \(citySanFr.distanceToCity)km more further is our next stop - \(citySanFr.nameCity).
This is a big city with population of \(citySanFr.populationCity) people.
This is an expensive city. There we expect to spend:
\(hotelSanFr)$ on a hotel.
\(foodSanFr)$ on food.

""")
var expensesSanFr = 0

if budget >= Int(carExpenses) {
    print("We take \(car.brand ?? "Default") \(car.model ?? "Default")")
    expensesSanFr = Int(carExpenses) + hotelSanFr + foodSanFr
} else if budget >= Int(otherCarExpenses) {
    print("We take \(otherCar.brand ?? "Default") \(otherCar.model ?? "Default")")
    expensesSanFr = Int(otherCarExpenses) + hotelSanFr + foodSanFr
} else {
    print("Asking for help to get to the next point")
    expensesSanFr = hotelSanFr + foodSanFr
}


//======== Озеро Тахо ========


var tahoe: City = (nameCity: "Tahoe lake", distanceToCity: 326, populationCity: 0)

var daysInTahoe = 1
hotelCost = 100
foodOnePerson = 40

var hotelTahoe = hotelCost * daysInTahoe
var foodTahoe = quantityOfPersons * foodOnePerson * daysInTahoe

//----Заводим новые виды транспорта. Поезд и автобус делаем недоступным----

car = (brand: "Hummer", model: "H1", rentCost: 75, fuelСonsumption: 25, ticketCost: nil)

otherCar = (brand: "Tesla", model: "Model S", rentCost: 75, fuelСonsumption: 0, ticketCost: nil)

//----Считаем расходы на машины----

carExpenses = Float((car.rentCost ?? 0) * daysInTahoe) + (Float((car.fuelСonsumption ?? 0) * tahoe.distanceToCity)) * gasCostUSD / 100

otherCarExpenses = Float((otherCar.rentCost ?? 0) * daysInTahoe) + (Float((car.fuelСonsumption ?? 0) * tahoe.distanceToCity)) * gasCostUSD / 100

print("""
Next stop is \(tahoe.nameCity). It is in \(tahoe.distanceToCity)km from \(citySanFr.nameCity).
There we expect to spend:
\(hotelTahoe)$ on a hotel.
\(foodTahoe)$ on food.

""")

var expensesTahoe = 0

//----Выбираем у кого меньше расход. Hummer или Tesla"

if (car.fuelСonsumption ?? 0) < (otherCar.fuelСonsumption ?? 0) {
    print("We take \(car.brand ?? "Default") \(car.model ?? "Default")")
    expensesTahoe = Int(carExpenses) + hotelTahoe + foodTahoe
} else {
    print("We take \(otherCar.brand ?? "Default") \(otherCar.model ?? "Default")")
    expensesTahoe = Int(otherCarExpenses) + hotelTahoe + foodTahoe
}


//======== Нацианальный парк Йосемити ========


var yose: City = (nameCity: "Yosemite national park", distanceToCity: 260, populationCity: 0)

var daysInYose = 1
foodOnePerson = 40

var foodYose = quantityOfPersons * foodOnePerson * daysInYose

//----Заводим новые виды транспорта. Поезд и автобус делаем недоступным----

car = (brand: "Mercedes", model: "S-klasse", rentCost: 120, fuelСonsumption: 12, ticketCost: nil)

otherCar = (brand: "Chevrolet", model: "Camaro", rentCost: 75, fuelСonsumption: 15, ticketCost: nil)

//----Считаем расходы на машины----

carExpenses = Float((car.rentCost ?? 0) * daysInYose) + (Float((car.fuelСonsumption ?? 0) * yose.distanceToCity)) * gasCostUSD / 100

otherCarExpenses = Float((otherCar.rentCost ?? 0) * daysInYose) + (Float((car.fuelСonsumption ?? 0) * yose.distanceToCity)) * gasCostUSD / 100

print("""
Then we are going to visit \(yose.nameCity). We are going drive \(yose.distanceToCity)km on highway
to visit this park.
We are planning to spend on food \(foodYose)$.
We decide not to stay in hotel and move to next point.

""")

var expensesYose = 0

//----Выбираем у кого меньше стоиомость аренды. Mercedes или Chevrolet"

if (car.rentCost ?? 0) < (otherCar.rentCost ?? 0) {
    print("We take \(car.brand ?? "Default") \(car.model ?? "Default")")
    expensesYose = Int(carExpenses) + foodYose
} else {
    print("We take \(otherCar.brand ?? "Default") \(otherCar.model ?? "Default")")
    expensesYose = Int(otherCarExpenses) + foodYose
}

//======== Фресно ========

var fresno: City = (nameCity: "Fresno", distanceToCity: 150, populationCity: 525010)

var daysInFresno = 1
hotelCost = 80
foodOnePerson = 40

var foodFresno = quantityOfPersons * foodOnePerson * daysInFresno
var hotelFresno = hotelCost * daysInFresno

//----Заводим новые виды транспорта. Поезд и автобус делаем недоступным----

car = (brand: "Betley", model: "Continental GT", rentCost: 150, fuelСonsumption: 14, ticketCost: nil)

otherCar = (brand: "Lamborghini", model: "Aventador", rentCost: 200, fuelСonsumption: 17, ticketCost: nil)

//----Считаем расходы на машины----

carExpenses = Float((car.rentCost ?? 0) * daysInFresno) + (Float((car.fuelСonsumption ?? 0) * fresno.distanceToCity)) * gasCostUSD / 100

otherCarExpenses = Float((otherCar.rentCost ?? 0) * daysInFresno) + (Float((car.fuelСonsumption ?? 0) * fresno.distanceToCity)) * gasCostUSD / 100

print ("""
Next city is \(fresno.nameCity). It is \(fresno.distanceToCity)km from \(yose.nameCity).
Population is \(fresno.populationCity) people.
Our expenses:
\(foodFresno)$ on food.
\(hotelFresno)$ on a hotel.

""")

var expensesFresno = 0

//----Выбираем у кого меньше стоиомость расходов всего. Bentley или Lamborghini"

if carExpenses < otherCarExpenses {
    print("We take \(car.brand ?? "Default") \(car.model ?? "Default")")
    expensesFresno = Int(carExpenses) + foodYose + hotelFresno
} else {
    print("We take \(otherCar.brand ?? "Default") \(otherCar.model ?? "Default")")
    expensesFresno = Int(otherCarExpenses) + foodFresno + hotelFresno
}

//----Итоговые расчеты----

let totalHotel = hotelFresno + hotelTahoe + hotelSanFr + hotelLA + hotelMonterey + hotelSanLO

let totalFood = foodYose + foodFresno + foodTahoe + foodSanFr + foodLA + foodMonterey + foodSanLO

let totalDistanceUSA = fresno.distanceToCity + yose.distanceToCity + tahoe.distanceToCity + Int(distanceInLA) + cityMonterey.distanceToCity + citySanFr.distanceToCity + citySanLO.distanceToCity

let totalDays = daysInLA + daysInFresno + daysInTahoe + daysInMonterey + daysInSanFr + daysInSanLO + daysInYose

let averageSpeed = 90

let totalTimeOnHighway = (totalDistanceUSA) / averageSpeed

let totalExpenses = expensesLA + expensesYose + expensesTahoe + expensesFresno + expensesSanLO + expensesStartPoint + expensesSanFr + expensesMonterey
print ("""
At this point during \(totalDays) days of our trip and \(totalDistanceUSA)km
of driving on a car we expect to spend :
On tickets          - \((airplane.ticketCost ?? 0) * quantityOfPersons)$
On living in hotels - \(totalHotel)$
On food             - \(totalFood)$

Total expenses is   - \(totalExpenses)$
""")
